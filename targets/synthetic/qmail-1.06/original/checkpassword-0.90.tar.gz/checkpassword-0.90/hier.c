#include "auto_home.h"

void hier()
{
  c(auto_home,"bin","checkpassword",-1,-1,0700);
}
