
FMWLoad={"Status":'<% CFG_GET(TMP_DOWNLD_ST+1);%>'};