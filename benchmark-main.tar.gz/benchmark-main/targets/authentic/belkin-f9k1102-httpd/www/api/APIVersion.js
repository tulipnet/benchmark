
APIVersion={"RequestID":'<% CGI_QUERY(RequestID);%>',"Version":"1"}