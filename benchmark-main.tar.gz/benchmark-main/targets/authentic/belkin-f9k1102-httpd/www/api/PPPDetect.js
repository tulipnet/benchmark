
PPPSver={"Status":'0<% CFG_GET(STS_WAN_CHK_PPPSVR);%>'};