
var MAX_STR_SZ=10;var STR_IP=0;var STR_MSK=1;var STR_GW=2;var STR_ME=3;<%CFG_MAP_ARY(str,RT_ST_RT,10);%>