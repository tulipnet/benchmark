
var bkup_file='<% CFG_GET(STS_BK_FNAME);%>';