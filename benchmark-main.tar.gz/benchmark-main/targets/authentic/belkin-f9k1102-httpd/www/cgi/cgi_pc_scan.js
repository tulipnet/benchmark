
var cgi_devs_chk_list=[<%CFG_ARY(STS_DEVS_CHK,256);%>null];