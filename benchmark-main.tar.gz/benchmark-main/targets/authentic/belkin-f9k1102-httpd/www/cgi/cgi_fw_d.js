
var MAX_DMZ_SZ=2;<%CFG_MAP(dmz_enable,NAT_DMZ_EN);%><%CFG_MAP(dmz_host,NAT_DMZ_HOST);%><%CFG_MAP(lan_ip,LAN_IP);%><%CFG_MAP(wan_ip,STS_WAN_IP);%>