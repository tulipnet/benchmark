
var cgi_devs_list=[<%CFG_ARY(STS_DEVS_LST,256);%>null];