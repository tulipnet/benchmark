
var user=[<%CGI_LOGIN_LST();%>null];