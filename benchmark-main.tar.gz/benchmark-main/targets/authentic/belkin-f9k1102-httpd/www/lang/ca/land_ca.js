
LangM.push({"2100":'Accès refusé. Entrez le mot de passe du routeur pour permettre l\'accès temporaire à la page ou aux services bloqués.','2101':'Page de renvoi','2102':'Allez','':null});