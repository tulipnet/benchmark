
LangM.push({'htWANMainContent':'Sélectionnez le type de connexion :','700':'Suivant','':null});