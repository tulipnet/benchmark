
LangM.push({'htWANMainContent':'选择连接类型：','700':'下一步','':null});