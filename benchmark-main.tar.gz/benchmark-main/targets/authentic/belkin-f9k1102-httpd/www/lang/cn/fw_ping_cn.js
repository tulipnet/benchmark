
LangM.push({'121':'<b>高级功能！</b>您可以配置路由器使其对ICMP ping不响应（ping广域网端口）。这样的配置可提高安全水平。','1076':'阻挡ICMP Ping攻击','':null});