
LangM.push({'htWANMainContent':'Vælg tilslutningstype:','700':'Næste','':null});