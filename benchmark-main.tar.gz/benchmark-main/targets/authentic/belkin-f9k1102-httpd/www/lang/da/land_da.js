
LangM.push({"2100":'Adgang nægtet. Indtast routerens adgangskode for at få midlertidig adgang til den blokerede side eller servicer.','2101':'Landing Page','2102':'UDFØR','':null});