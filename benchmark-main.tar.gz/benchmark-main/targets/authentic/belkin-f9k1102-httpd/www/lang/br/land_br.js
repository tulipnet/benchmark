
LangM.push({"2100":'Acesso negado. Insira a senha do Roteador para permitir o acesso temporário à página ou serviços bloqueados.','2101':'Página de aterrissagem','2102':'IR','':null});