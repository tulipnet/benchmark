
LangM.push({'htWANMainContent':'Selecionar tipo de conexão:','700':'Avançar','':null});