#ifndef NVRAM_H
#define NVRAM_H

char* nvram_get(char* param);

#endif /* ifndef NVRAM_H

char* nvram_get(char* param);
 */
